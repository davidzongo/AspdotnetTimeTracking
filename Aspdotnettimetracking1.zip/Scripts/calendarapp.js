﻿
function ShowEventPopup(start, end, allDay) {
   
    ClearPopupFormValues();
    start = $.fullCalendar.formatDate(start, 'MM/dd/yyyy');
    end = $.fullCalendar.formatDate(end, 'MM/dd/yyyy');

    $('#eventDate').val(start);

    if (start != end) {

      
        $('#chkRec').prop('checked', true);
        $('#addEventEndDate').val(end);
        $('#RecEvent').show();
    }
    $('#popupEventForm').show();
    $('#eventTitle').focus();
}

function ClearPopupFormValues() {
    $('#eventID').val("");
    $('#eventTitle').val("");
    $('#eventDateTime').val("");
    $('#addEventDuration').val("");
}
$('#btnClose').click(function () {
    ClearPopupFormValues();
    $('#popupEventForm').hide();
});
$('#btnPopupCancel').click(function () {

    ClearPopupFormValues();
    $('#popupEventForm').hide();

});

$('#btnPopupSave').click(function () {

    $('#popupEventForm').hide();
    var title= $('#eventTitle').val();
    var start= $('#eventDate').val();
    var end = $('#eventDate').val();
    var hours = $('#addEventDuration').val();
    var allDay = hours > 7;
    var isMultiple = false;
    if ($('#chkRec').is(':checked')) {

        isMultiple = true;
        end = $('#addEventEndDate').val();
    }

    var dataRow = {
        'EventName': title,//$('#eventTitle').val(),
        'StartDateString':start,// $('#eventDate').val(),
        'EndDateString': end,//$('#eventDate').val(),
        //'EventTime': $('#eventTime').val(),
        'EventDuration':hours,
        'TypeId': $("#addEventType").val(),
        'EventNote': $('#addEventDesc').val(),
        'IsMultiple': isMultiple
    }




    ClearPopupFormValues();

    $.ajax({
        type: 'POST',
        url: "/TimeOffManagement/SaveEvent",
        data: dataRow,
        success: function (response) {
            if (response == 'True') {
                $('#calendar').fullCalendar('refetchEvents');
                // alert('New event saved!');
                $('#calendar').fullCalendar('renderEvent',
                		{
                		    title: title,
                		    start: start,
                		    end: end,
                		    allDay: allDay
                		},
                		true // make the event "stick"
                	);
            }
            else {
                alert('Error, could not save event!');
            }
        }
    });

});


function UpdateEvent(EventID, EventStart, EventEnd) {

    var dataRow = {
        'EventId': EventID,
        'NewEventStart': EventStart,
        'NewEventEnd': EventEnd
    }

    alert(EventStart);

    $.ajax({
        type: 'POST',
        url: "/TimeOffManagement/UpdateEvent",
        dataType: "json",
        contentType: "application/json",
        data: JSON.stringify(dataRow)
    });
}

$.ajax({
    type: "POST",
    // contentType: "application/json; charset=utf-8",
    data: "{}",
    url: "/TimeOffManagement/GetEventType",
    dataType: "json",
    success: ajaxSucceess,
    error: ajaxError


});

function ajaxSucceess(states) {
    //alert('here llooP');
    // running a loop
    $.each(states, function (index, value) {
        $("#addEventType").append($("<option></option>").val(this.LeaveTypeId).html(this.Name));
       // $("#event-box").append($("<div class='external-event ui-draggable' style='position: relative;'></div>").val(this.LeaveTypeId).html(this.Name));
        //
    });
}
function ajaxError(response) {
    // alert("Something seems Wrong");
    alert(response.status + ' ' + response.statusText);
};

//add check
$('#chkRec').click(function () {
    if ($(this).is(':checked')) {

        $('#RecEvent').show();
    }
    else {
        $('#RecEvent').hide();
    }
});